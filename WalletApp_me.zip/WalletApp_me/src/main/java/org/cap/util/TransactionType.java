package org.cap.util;

public enum TransactionType {
	DEBIT,CREDIT;
}
