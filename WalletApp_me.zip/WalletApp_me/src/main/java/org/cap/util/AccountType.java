package org.cap.util;

public enum AccountType {
	SAVINGS(1),CURRENT(2);
	private int value;
	AccountType(int value)
	{
		this.value=value;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}

}
