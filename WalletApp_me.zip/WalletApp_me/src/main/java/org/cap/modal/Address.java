package org.cap.modal;

public class Address {
	private int addressId;
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId() {
		this.addressId =(int) (Math.random() * 1000);
	}
	private String streetNo;
	private String doorNo;
	private String city;
	private String state;
	
	
	
	@Override
	public String toString() {
		return "Address: " + addressId + "\t" + streetNo + "\t" + doorNo + "\t" + city
				+ "\t" + state + "]";
	}
	//Constructors
	public Address(int addressId,String streetNo, String doorNo, String city, String state) {
		super();
		setAddressId();
		this.addressId=addressId;
		this.streetNo = streetNo;
		this.doorNo = doorNo;
		this.city = city;
		this.state = state;
	}
	public Address(String streetNo, String doorNo, String city, String state) {
		super();
		setAddressId();
		this.streetNo = streetNo;
		this.doorNo = doorNo;
		this.city = city;
		this.state = state;
	}
	public Address()
	{
		setAddressId();
	}
	
	//Getters and sEtters
	public String getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(String streetNo) {
		this.streetNo = streetNo;
	}
	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}



}
