package org.cap.modal;

import org.cap.util.TransactionType;

public class Transaction {
	
	private long transactionId;
	private double amount;
	private TransactionType transactionType;
	private String description;
	private Account fromAccount;
	private Account toAccount;
	
	
	//Constructors
	public Transaction()
	{
		
	}
	public Transaction(long transactionId, double amount, TransactionType transactionType, String description,
			Account fromAccount, Account toAccount) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transactionType = transactionType;
		this.description = description;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
	}

	
	//Getters and Setters
	public long getTransactionId() {
		return transactionId;
	}
	
	public void setTransactionId() {
		this.transactionId =(int) (Math.random() * 1000);
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Account getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(Account fromAccount) {
		this.fromAccount = fromAccount;
	}
	public Account getToAccount() {
		return toAccount;
	}
	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}
}
