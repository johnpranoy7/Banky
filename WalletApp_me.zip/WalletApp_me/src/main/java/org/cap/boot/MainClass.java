package org.cap.boot;

import java.util.List;

import org.cap.modal.Customer;
import org.cap.service.*;
import org.cap.view.UserInteraction;

public class MainClass {
	public static AccountService account= new AccountService();
	public static UserInteraction userInteraction=new UserInteraction();
	public static void main(String[] args)
	{
		List<Customer> allCustomers=account.database();
		userInteraction.showAllCustomers(allCustomers);
		while(true)
		{
			userInteraction.showMenu();
		}
	}
} 
