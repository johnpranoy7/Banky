package org.cap.view;
import java.time.LocalDate;
import java.util.*;

import org.cap.modal.*;
import org.cap.service.AccountService;
import org.cap.util.AccountType;

public class UserInteraction {
	public static AccountService account= new AccountService();
	Scanner s=new Scanner(System.in);
	static int i=0;
	public void showAllCustomers(List<Customer> customers)
	{
		System.out.println("Welcome to XYZ Bank");
		System.out.println("The Customers are");
		for(Customer allCustomer: customers )
		{
			System.out.println(allCustomer);
		}
	}
	
	public void getAmount()
	{
		System.out.println("Enter Amount");
		
	}
	
	public void showMenu()
	{
		System.out.println("Select CustomerID:");
		long customerId=s.nextLong();
		Customer customer=account.getCustomer(customerId);
		boolean validateCustomer = account.validateCustomer(customerId);
		if(validateCustomer==true)
		{	
		System.out.println("1.New Account  2.ExistingAccount  3.Exit");
		switch(s.nextInt())
		{
			case 1:
				System.out.println("Enter Opening Balance:");
				Double openingBalance=s.nextDouble();
				System.out.println("Enter AccountType");
				
				String accountTypeString=s.next();
				AccountType accountType= account.acceptAccountType(accountTypeString);
				
				//System.out.println("Enter OpeningDate");
				LocalDate openingDate=LocalDate.now();
				Account customerAccount = new Account(openingBalance,accountType,openingDate,customer);
				account.pushCustomerAccount(customerAccount);
				account.getAllAccounts(customer);
			
				//Create new Account; Enter DEtails
				break;
			case 2: 
				System.out.println("Enter Accountno");
				long searchAccountNumber=s.nextLong();
				System.out.println(account.validateAccount(customer,searchAccountNumber));
				if(account.validateAccount(customer,searchAccountNumber))
					{
						//customer object of Customer
						System.out.println("1.Withdraw 2.Deposit 3.CheckBalance");
						switch(s.nextInt())
						{
						  case 1:	customer.withdraw();//withdraw
							  break;
						  case 2:  //deposit
							  break;
						  case 3:  //checkBalance
							  break;
						  default:
							  System.out.println("Sorry no such Option");
						}
					}break;
			case 3:
				System.exit(0);
		}
		}
		else
		{
			System.out.println("Sorry No such Customer");
		}
		
		
	}
}
