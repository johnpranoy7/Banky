package org.cap.dao;
import org.cap.modal.*;
import java.util.*;

import org.cap.modal.Account;
import org.cap.modal.Address;
import org.cap.modal.Customer;
import org.cap.util.AccountType;

public class AccountDAO implements IAccountDAO{
	public static List<Customer> customers = new ArrayList<Customer>();
	public static List<Account>	customeraccounts=new ArrayList<Account>();
	
	public static List<Customer> database()
	{
		customers.add(new Customer(100,"John","Pranoy","789456123","johnpranoy7@gmail.com",new Address(1,"Street1","Door1","Hyd","Telangana")));
		customers.add(new Customer(101,"Ajay","Varma","123456258","ajayvarma@gmail.com",new Address(2,"Street2","Door1","Hyd","Telangana")));
		customers.add(new Customer(102,"Samosa","Man","56769123","peacemaker@gmail.com",new Address(3,"Street2","Door2","Chn","TamilNadu")));
		return customers;
	}

	

	public void pushCustomerAccount(Account customerAccount)
	{
		customerAccount.getCustomer().customerAccounts.add(customerAccount);
	}
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		for(Customer c: customers)
		{
			System.out.println(c);
		}
		return null;
	}

	@Override
	public boolean validateCustomer(long customerId) {
		for(Customer allCustomer: customers)
		{
			if(allCustomer.getCustomerId()==customerId)
			{
				return true;
			}
		}
		// TODO Auto-generated method stub
		return false;
	}
	
	public Customer getCustomer(long customerId)
	{
		for(Customer allCustomer: customers)
		{
			if(allCustomer.getCustomerId()==customerId)
				return allCustomer;
		}
		return null;
	}

	public Customer checkBalance(Customer currentCustomer) {
		System.out.println(currentCustomer);
		// TODO Auto-generated method stub
		return null;
	}

	public AccountType acceptAccountType(String accountTypeString) {
		
		AccountType accountType = null;
		accountType=AccountType.valueOf(accountTypeString);
		System.out.println(accountType);
		// TODO Auto-generated method stub
		return accountType;
	}



	public List<Account> getAllAccounts(Customer customer) {
		return customer.getCustomerAccounts();
		// TODO Auto-generated method stub
	}



	public boolean validateAccount(Customer customer,long validateAccountno) {
		List<Account> validAccount=customer.getCustomerAccounts();
		for(Account x: validAccount)
		{
			if(x.getAccountNo()==validateAccountno)
				return true;
		}
		// TODO Auto-generated method stub
		return false;
	}
	

}
