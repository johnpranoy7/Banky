package org.cap.service;

import java.util.List;
import java.util.ListIterator;

import org.cap.dao.AccountDAO;
import org.cap.modal.Account;
import org.cap.modal.Customer;
import org.cap.util.AccountType;

public class AccountService implements IAccountService{
	public static AccountDAO accountDAO = new AccountDAO();
	public static List<Customer> database()
	{
		return AccountDAO.database();
	}
	
	public void pushCustomerAccount(Account customerAccount)
	{
		accountDAO.pushCustomerAccount(customerAccount);
	}
	public Customer getCustomer(long customerId)
	{
		return accountDAO.getCustomer(customerId);
	}
	
	public Customer checkBalance(Customer currentCustomer)
	{
		return accountDAO.checkBalance(currentCustomer);
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return accountDAO.getAllCustomers();
	}

	@Override
	public boolean validateCustomer(long searchAccountNumber) {
		// TODO Auto-generated method stub
		return accountDAO.validateCustomer(searchAccountNumber);
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		
	}

	public AccountType acceptAccountType(String accountTypeString) {
		// TODO Auto-generated method stub
		return accountDAO.acceptAccountType(accountTypeString);
	}

	public void getAllAccounts(Customer customer) {
		 List<Account> customersAccounts=customer.getCustomerAccounts();
		 ListIterator<Account> iterator = customersAccounts.listIterator();
		 for(Account x: customersAccounts)
			 System.out.println(x);
		// while(iterator.hasNext())
		//	 System.out.println(iterator);
		 // TODO Auto-generated method stub
		
	}

	public boolean  validateAccount(Customer customer,long searchAccountNumber) {
		// TODO Auto-generated method stub
		return accountDAO.validateAccount(customer,searchAccountNumber);
	}

}
