package org.cap.service;
import java.util.*;
import org.cap.modal.Customer;

public interface IAccountService {
	public List<Customer> getAllCustomers();
	public void createAccount();
	public boolean validateCustomer(long searchAccountNumber);
}
