package org.cap.boot;

import org.cap.service.*;
import org.cap.view.UserInteraction;

public class MainClass {
	public static AccountService account= new AccountService();
	public static UserInteraction userInteraction=new UserInteraction();
	public static void main(String[] args)
	{
		userInteraction.FirstScreen();
		account.database();
	}
}
