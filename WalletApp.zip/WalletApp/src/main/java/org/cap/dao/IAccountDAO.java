package org.cap.dao;

import java.util.List;

import org.cap.modal.Customer;

public interface IAccountDAO {
	public List<Customer> getAllCustomers();
	public boolean validateCustomer(int customerId);
}
