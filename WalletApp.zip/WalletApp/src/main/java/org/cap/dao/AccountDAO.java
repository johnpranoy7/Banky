package org.cap.dao;

import java.util.*;

import org.cap.modal.Account;
import org.cap.modal.Address;
import org.cap.modal.Customer;

public class AccountDAO implements IAccountDAO{
	public static List<Customer> customers = new ArrayList<Customer>();
	
	public static List<Customer> database()
	{
		
		customers.add(new Customer(100,"John","Pranoy","789456123","johnpranoy7@gmail.com",new Address(1,"Street1","Door1","Hyd","Telangana")));
		customers.add(new Customer(101,"Ajay","Varma","123456258","ajayvarma@gmail.com",new Address(2,"Street2","Door1","Hyd","Telangana")));
		customers.add(new Customer(102,"Lakshmi","Narayana","5676945123","peacemaker@gmail.com",new Address(3,"Street2","Door2","Chn","TamilNadu")));
		return customers;
		
	}
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		for(Customer c: customers)
		{
			System.out.println(c);
		}
		return null;
	}

	@Override
	public boolean validateCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

}
