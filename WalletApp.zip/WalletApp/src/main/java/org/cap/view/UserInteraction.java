package org.cap.view;
import java.util.*;

public class UserInteraction {
	
	Scanner s=new Scanner(System.in);
	
	public void FirstScreen()
	{
		System.out.println("Welcome to XYZ Bank");
		System.out.println("The Customers are");
	}
}
