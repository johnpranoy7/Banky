package org.cap.modal;

import java.time.LocalDate;

import org.cap.util.AccountType;

public class Account {
	
	private double openingBalance;
	private AccountType accountType; 
	private LocalDate openingDate;
	private String description;
	private Customer customer;
	
	//Constructors
	public Account()
	{
		
	}
	public Account(long accountNo, double openingBalance, AccountType accountType, LocalDate openingDate,
			String description, Customer customer) {
		super();
		this.accountNo = accountNo;
		this.openingBalance = openingBalance;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.description = description;
		this.customer = customer;
	}
	
	//Getters and Setters
	private long accountNo;
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
