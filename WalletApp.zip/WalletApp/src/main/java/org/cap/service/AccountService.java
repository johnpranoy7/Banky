package org.cap.service;

import java.util.List;

import org.cap.dao.AccountDAO;
import org.cap.modal.Customer;

public class AccountService implements IAccountService{
	public static AccountDAO accountDAO = new AccountDAO();
	public static List<Customer> database()
	{
		return AccountDAO.database();
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		
	}

}
